package com.example.myapplication.listeners;

import com.example.myapplication.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
